<!DOCTYPE HTML>
<html lang="pl">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?php echo e($title ?? '📝 Fabryka postów'); ?></title>
    <link rel="icon" href="/img/favicon.svg">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="/css/app.css" media="screen,projection"/>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col s12">
            <h1><?php echo e($title ?? '📝 Fabryka postów'); ?></h1>
        </div>
    </div>
    <div class="row">
        <?php echo $__env->yieldContent('menu'); ?>
    </div>
</div>
<hr/>

<?php echo $__env->yieldContent('content'); ?>


<script src="/js/app.js"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\_code\studia\semestr-6\zaawansowane-serwisy-internetowe\s6-php-laravel-project\resources\views/main.blade.php ENDPATH**/ ?>