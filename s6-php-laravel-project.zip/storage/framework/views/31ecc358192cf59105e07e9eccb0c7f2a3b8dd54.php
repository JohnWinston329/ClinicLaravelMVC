<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col s12 m6 l6">
                <a href="/posts">
                    <div class="card-panel hoverable center">
                        <h5>Wszystkie posty</h5>
                    </div>
                </a>
            </div>
            <div class="col s12 m6 l6">
                <a href="/posts/new">
                    <div class="card-panel hoverable center">
                        <h5>Nowy post</h5>
                    </div>
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\_code\studia\semestr-6\zaawansowane-serwisy-internetowe\s6-php-laravel-project\resources\views/index.blade.php ENDPATH**/ ?>